<!DOCTYPE html>
<html>
<head>
    <title>Регистрация и Вход</title>
</head>
<body>
    <h1>Регистрация и Вход</h1>
    <p>Выберите действие:</p>
    <a href="register.php">Зарегистрироваться</a> | <a href="login.php">Войти</a>
</body>
</html>
