<!DOCTYPE html>
<html>
<head>
    <title>Главная страница сайта</title>
</head>
<body>
    <h1>Главная страница сайта</h1>
    <?php
    session_start();
    if (isset($_SESSION['user_id'])) {
        // Если пользователь авторизован, отобразите информацию о его профиле
        echo "Добро пожаловать, " . $_SESSION['user_name'] . "!";
        echo "<br><a href='profile.php'>Посмотреть профиль</a>";
        // Добавьте другую информацию о сайте
    } else {
        // Если пользователь не авторизован, перенаправьте его на страницу входа
        header("Location: login.php");
    }
    ?>
</body>
</html>
